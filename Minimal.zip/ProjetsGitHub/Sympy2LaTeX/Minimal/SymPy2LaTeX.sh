#!/bin/bash
# on se déplace vers le dossier de travail
echo "$0"
echo "$(dirname "${0}")"
cd "$(dirname "${0}")"
# conda doit etre installe avant et etre accessible
eval "$(conda shell.bash hook)"
conda activate ./envs
echo environnement conda activé
# On lance
python SymPy2LaTeX.py
echo fermeture de la fenêtre
